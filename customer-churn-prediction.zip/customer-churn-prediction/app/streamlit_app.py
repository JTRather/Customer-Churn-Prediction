"""
Customer Churn Analyzer - Streamlit app.
Run locally with:  streamlit run app/streamlit_app.py
Loads the trained pipeline from models/churn_model.pkl and lets a user
upload a CSV of customers to score, or inspect one customer at a time.
"""
import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Customer Churn Analyzer", layout="wide")

MODEL_PATH = "models/churn_model.pkl"
CONFIG_PATH = "models/feature_config.pkl"


@st.cache_resource
def load_model():
    pipe = joblib.load(MODEL_PATH)
    cfg = joblib.load(CONFIG_PATH)
    return pipe, cfg["num_cols"], cfg["cat_cols"]


def risk_tier(p):
    if p <= 0.20:
        return "Low"
    elif p <= 0.50:
        return "Moderate"
    elif p <= 0.75:
        return "High"
    return "Critical"


st.title("📉 Customer Churn Analyzer")
st.caption("Upload a customer file to score churn risk, or explore a single customer below.")

pipe, num_cols, cat_cols = load_model()
required_cols = num_cols + cat_cols

uploaded = st.file_uploader("Upload a customer CSV", type="csv")

if uploaded:
    df = pd.read_csv(uploaded)
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        st.error(f"Missing required columns: {missing}")
    else:
        df["churn_probability"] = pipe.predict_proba(df[required_cols])[:, 1]
        df["risk_tier"] = df["churn_probability"].apply(risk_tier)
        if "monthly_charges" in df.columns:
            df["annual_revenue_at_risk"] = df["monthly_charges"] * 12 * df["churn_probability"]

        st.subheader("Scored Customers")
        st.dataframe(
            df.sort_values("churn_probability", ascending=False),
            use_container_width=True,
        )

        col1, col2, col3 = st.columns(3)
        col1.metric("Customers Scored", len(df))
        col2.metric("Avg. Churn Probability", f"{df['churn_probability'].mean():.1%}")
        if "annual_revenue_at_risk" in df.columns:
            col3.metric("Total Revenue at Risk", f"${df['annual_revenue_at_risk'].sum():,.0f}")

        st.download_button(
            "Download scored file",
            df.to_csv(index=False).encode("utf-8"),
            "scored_customers.csv",
            "text/csv",
        )
else:
    st.info("👆 Upload a CSV with columns: " + ", ".join(required_cols))

st.divider()
st.subheader("Score a Single Customer")

with st.form("single_customer"):
    cols = st.columns(3)
    inputs = {}
    for i, c in enumerate(num_cols):
        inputs[c] = cols[i % 3].number_input(c, value=0.0)
    for i, c in enumerate(cat_cols):
        inputs[c] = cols[i % 3].text_input(c, value="")
    submitted = st.form_submit_button("Predict")

if submitted:
    single_df = pd.DataFrame([inputs])
    prob = pipe.predict_proba(single_df[required_cols])[:, 1][0]
    tier = risk_tier(prob)
    st.metric("Churn Probability", f"{prob:.1%}", tier)
