import joblib
import pandas as pd

DATA = "/home/claude/customer-churn-prediction/data/processed/customer_master.csv"
df = pd.read_csv(DATA)

pipe = joblib.load("/home/claude/customer-churn-prediction/models/churn_model.pkl")
cfg = joblib.load("/home/claude/customer-churn-prediction/models/feature_config.pkl")
num_cols, cat_cols = cfg["num_cols"], cfg["cat_cols"]

X = df[num_cols + cat_cols]
df["churn_probability"] = pipe.predict_proba(X)[:, 1]


def risk_tier(p):
    if p <= 0.20:
        return "Low"
    elif p <= 0.50:
        return "Moderate"
    elif p <= 0.75:
        return "High"
    else:
        return "Critical"


df["risk_tier"] = df["churn_probability"].apply(risk_tier)
df["annual_revenue"] = df["monthly_charges"] * 12
df["annual_revenue_at_risk"] = df["annual_revenue"] * df["churn_probability"]

summary = df.groupby("risk_tier").agg(
    customers=("customer_id", "count"),
    avg_probability=("churn_probability", "mean"),
    total_revenue_at_risk=("annual_revenue_at_risk", "sum"),
).round(2).reset_index()

print(summary.to_string(index=False))

total_at_risk = df.loc[df["risk_tier"].isin(["High", "Critical"]), "annual_revenue_at_risk"].sum()
print(f"\nTotal annual revenue at risk (High+Critical): ${total_at_risk:,.0f}")

df.sort_values("churn_probability", ascending=False).to_csv(
    "/home/claude/customer-churn-prediction/data/processed/customer_risk_scores.csv", index=False
)
summary.to_csv("/home/claude/customer-churn-prediction/reports/risk_tier_summary.csv", index=False)

with open("/home/claude/customer-churn-prediction/reports/revenue_at_risk.txt", "w") as f:
    f.write(f"{total_at_risk:.2f}")
