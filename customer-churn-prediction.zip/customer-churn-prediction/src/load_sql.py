"""Loads the raw customer CSV into a normalized SQLite database (schema.sql)
and runs the business analysis queries, saving results as CSVs for the
dashboard and notebooks to consume."""
import sqlite3
import pandas as pd

RAW = "/home/claude/customer-churn-prediction/data/raw/customers.csv"
DB = "/home/claude/customer-churn-prediction/data/processed/churn.db"
SCHEMA = "/home/claude/customer-churn-prediction/sql/schema.sql"

df = pd.read_csv(RAW)

conn = sqlite3.connect(DB)
with open(SCHEMA) as f:
    conn.executescript(f.read())

df[["customer_id", "age", "gender", "location"]].to_sql("customers", conn, if_exists="append", index=False)

df.rename(columns={"signup_tenure_months": "tenure_months"})[
    ["customer_id", "plan", "contract_type", "payment_method", "monthly_charges", "total_charges", "tenure_months"]
].to_sql("subscriptions", conn, if_exists="append", index=False)

df[["customer_id", "login_freq_per_week", "avg_session_minutes", "days_since_last_login"]].to_sql(
    "activity", conn, if_exists="append", index=False
)

df.rename(columns={"support_tickets": "tickets"})[["customer_id", "tickets"]].to_sql(
    "support", conn, if_exists="append", index=False
)

df[["customer_id", "churned"]].to_sql("churn", conn, if_exists="append", index=False)

conn.execute("""
DROP VIEW IF EXISTS customer_master;
""")
conn.execute("""
CREATE VIEW customer_master AS
SELECT
    c.customer_id, c.age, c.gender, c.location,
    s.plan, s.contract_type, s.payment_method, s.monthly_charges, s.total_charges, s.tenure_months,
    a.login_freq_per_week, a.avg_session_minutes, a.days_since_last_login,
    sp.tickets AS support_tickets, ch.churned
FROM customers c
JOIN subscriptions s ON c.customer_id = s.customer_id
JOIN activity a ON c.customer_id = a.customer_id
JOIN support sp ON c.customer_id = sp.customer_id
JOIN churn ch ON c.customer_id = ch.customer_id;
""")
conn.commit()

overall = pd.read_sql(
    "SELECT COUNT(*) total_customers, SUM(churned) churned_customers, "
    "ROUND(100.0*SUM(churned)/COUNT(*),2) churn_rate_pct FROM customer_master", conn)

by_contract = pd.read_sql(
    "SELECT contract_type, COUNT(*) customers, ROUND(100.0*SUM(churned)/COUNT(*),2) churn_rate_pct "
    "FROM customer_master GROUP BY contract_type ORDER BY churn_rate_pct DESC", conn)

by_tenure = pd.read_sql("""
SELECT CASE
    WHEN tenure_months <= 6 THEN '0-6 months'
    WHEN tenure_months <= 12 THEN '7-12 months'
    WHEN tenure_months <= 24 THEN '13-24 months'
    ELSE '25+ months' END AS tenure_bucket,
    COUNT(*) customers, ROUND(100.0*SUM(churned)/COUNT(*),2) churn_rate_pct
FROM customer_master GROUP BY tenure_bucket ORDER BY MIN(tenure_months)
""", conn)

by_engagement = pd.read_sql("""
SELECT CASE
    WHEN login_freq_per_week < 2 THEN 'Low engagement'
    WHEN login_freq_per_week < 5 THEN 'Medium engagement'
    ELSE 'High engagement' END AS engagement_bucket,
    COUNT(*) customers, ROUND(100.0*SUM(churned)/COUNT(*),2) churn_rate_pct
FROM customer_master GROUP BY engagement_bucket
""", conn)

print("=== Overall ===\n", overall)
print("\n=== By contract ===\n", by_contract)
print("\n=== By tenure ===\n", by_tenure)
print("\n=== By engagement ===\n", by_engagement)

overall.to_csv("/home/claude/customer-churn-prediction/data/processed/eda_overall.csv", index=False)
by_contract.to_csv("/home/claude/customer-churn-prediction/data/processed/eda_by_contract.csv", index=False)
by_tenure.to_csv("/home/claude/customer-churn-prediction/data/processed/eda_by_tenure.csv", index=False)
by_engagement.to_csv("/home/claude/customer-churn-prediction/data/processed/eda_by_engagement.csv", index=False)

# Also export the joined master table for the ML pipeline
master_df = pd.read_sql("SELECT * FROM customer_master", conn)
master_df.to_csv("/home/claude/customer-churn-prediction/data/processed/customer_master.csv", index=False)

conn.close()
