import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (precision_score, recall_score, f1_score,
                              roc_auc_score, accuracy_score, confusion_matrix)
from xgboost import XGBClassifier

DATA = "/home/claude/customer-churn-prediction/data/processed/customer_master.csv"
df = pd.read_csv(DATA)

target = "churned"
num_cols = ["age", "monthly_charges", "total_charges", "tenure_months",
            "login_freq_per_week", "avg_session_minutes", "days_since_last_login",
            "support_tickets"]
cat_cols = ["gender", "location", "plan", "contract_type", "payment_method"]

X = df[num_cols + cat_cols]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

preprocessor = ColumnTransformer([
    ("num", StandardScaler(), num_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
])

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=8, class_weight="balanced", random_state=42),
    "XGBoost": XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.08,
                              scale_pos_weight=(y_train == 0).sum() / (y_train == 1).sum(),
                              eval_metric="logloss", random_state=42),
}

results = []
fitted_pipelines = {}

for name, model in models.items():
    pipe = Pipeline([("prep", preprocessor), ("clf", model)])
    pipe.fit(X_train, y_train)
    fitted_pipelines[name] = pipe

    proba = pipe.predict_proba(X_test)[:, 1]
    preds = (proba >= 0.5).astype(int)

    results.append({
        "model": name,
        "accuracy": round(accuracy_score(y_test, preds), 3),
        "precision": round(precision_score(y_test, preds), 3),
        "recall": round(recall_score(y_test, preds), 3),
        "f1": round(f1_score(y_test, preds), 3),
        "roc_auc": round(roc_auc_score(y_test, proba), 3),
    })

results_df = pd.DataFrame(results)
print(results_df.to_string(index=False))
results_df.to_csv("/home/claude/customer-churn-prediction/reports/model_comparison.csv", index=False)

# Best model by ROC-AUC -> becomes the production model
best_name = results_df.sort_values("roc_auc", ascending=False).iloc[0]["model"]
best_pipe = fitted_pipelines[best_name]
print(f"\nBest model: {best_name}")

joblib.dump(best_pipe, "/home/claude/customer-churn-prediction/models/churn_model.pkl")
joblib.dump({"num_cols": num_cols, "cat_cols": cat_cols}, "/home/claude/customer-churn-prediction/models/feature_config.pkl")

with open("/home/claude/customer-churn-prediction/reports/best_model.json", "w") as f:
    json.dump({"best_model": best_name}, f)

# Save test set predictions for the dashboard / revenue-at-risk calc
proba_best = best_pipe.predict_proba(X_test)[:, 1]
test_out = df.loc[X_test.index].copy()
test_out["churn_probability"] = proba_best
test_out.to_csv("/home/claude/customer-churn-prediction/data/processed/test_predictions.csv", index=False)

print("\nConfusion matrix (best model, threshold=0.5):")
print(confusion_matrix(y_test, (proba_best >= 0.5).astype(int)))
