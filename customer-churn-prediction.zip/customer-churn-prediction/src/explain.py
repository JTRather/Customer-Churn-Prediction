import json
import joblib
import numpy as np
import pandas as pd
import shap

DATA = "/home/claude/customer-churn-prediction/data/processed/customer_master.csv"
df = pd.read_csv(DATA)

pipe = joblib.load("/home/claude/customer-churn-prediction/models/churn_model.pkl")
cfg = joblib.load("/home/claude/customer-churn-prediction/models/feature_config.pkl")
num_cols, cat_cols = cfg["num_cols"], cfg["cat_cols"]

preprocessor = pipe.named_steps["prep"]
clf = pipe.named_steps["clf"]

X = df[num_cols + cat_cols]
X_trans = preprocessor.transform(X)
if hasattr(X_trans, "toarray"):
    X_trans = X_trans.toarray()

feature_names = list(preprocessor.get_feature_names_out())

# Sample a background + explain set (SHAP is expensive at 20k rows)
rng = np.random.RandomState(42)
bg_idx = rng.choice(len(X_trans), size=min(200, len(X_trans)), replace=False)
explain_idx = rng.choice(len(X_trans), size=min(1000, len(X_trans)), replace=False)

background = X_trans[bg_idx]
sample = X_trans[explain_idx]

explainer = shap.Explainer(clf.predict_proba, background, feature_names=feature_names)
shap_values = explainer(sample)

# shap_values has shape (n, features, 2) for predict_proba -> take churn=1 class
if shap_values.values.ndim == 3:
    sv = shap_values.values[:, :, 1]
else:
    sv = shap_values.values

# Global feature importance = mean absolute SHAP value
importance = pd.DataFrame({
    "feature": feature_names,
    "mean_abs_shap": np.abs(sv).mean(axis=0)
}).sort_values("mean_abs_shap", ascending=False)

# Roll one-hot columns back up to their original variable for a readable driver list
def base_feature(name):
    for c in cat_cols:
        if name.startswith(f"cat__{c}_"):
            return c
    return name.replace("num__", "")

importance["base_feature"] = importance["feature"].apply(base_feature)
driver_ranking = (
    importance.groupby("base_feature")["mean_abs_shap"].sum()
    .sort_values(ascending=False)
    .reset_index()
)
driver_ranking.to_csv("/home/claude/customer-churn-prediction/reports/churn_drivers.csv", index=False)
print("=== Top churn drivers (global) ===")
print(driver_ranking.head(10).to_string(index=False))

# Individual customer explanation for a few high-risk examples
probs = clf.predict_proba(sample)[:, 1]
top_risk_local_idx = np.argsort(probs)[::-1][:5]

customer_ids = df.iloc[explain_idx]["customer_id"].values
individual_explanations = []
for i in top_risk_local_idx:
    row_shap = sv[i]
    top_factors = pd.Series(row_shap, index=feature_names).sort_values(key=np.abs, ascending=False).head(5)
    individual_explanations.append({
        "customer_id": customer_ids[i],
        "churn_probability": round(float(probs[i]), 3),
        "top_factors": [
            {"feature": f, "shap_value": round(float(v), 3)} for f, v in top_factors.items()
        ]
    })

with open("/home/claude/customer-churn-prediction/reports/individual_explanations.json", "w") as f:
    json.dump(individual_explanations, f, indent=2)

print("\n=== Sample individual explanation ===")
print(json.dumps(individual_explanations[0], indent=2))
