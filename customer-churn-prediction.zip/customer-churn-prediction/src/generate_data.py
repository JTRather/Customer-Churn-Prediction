"""
Generates a synthetic (but realistic) customer churn dataset.
Churn probability is driven by contract type, tenure, engagement,
support tickets, and monthly charges -- mirroring real subscription
business patterns described in the project brief.
"""
import numpy as np
import pandas as pd

np.random.seed(42)
N = 20000  # portfolio-scale; same logic works at 100k, just slower to train

locations = ["Atlanta", "Chicago", "Austin", "Denver", "Seattle", "Miami",
             "Boston", "Phoenix", "Portland", "Nashville"]
contract_types = np.random.choice(["Monthly", "Annual", "Two-Year"], N, p=[0.55, 0.30, 0.15])
plans = np.random.choice(["Basic", "Standard", "Premium"], N, p=[0.35, 0.40, 0.25])
payment_methods = np.random.choice(
    ["Credit Card", "Bank Transfer", "PayPal", "Mailed Check"], N, p=[0.45, 0.25, 0.20, 0.10]
)

age = np.clip(np.random.normal(40, 13, N), 18, 85).astype(int)
gender = np.random.choice(["F", "M"], N)
location = np.random.choice(locations, N)

tenure_months = np.clip(np.random.exponential(scale=20, size=N), 0, 72).astype(int)

plan_base_price = {"Basic": 29.99, "Standard": 54.99, "Premium": 79.99}
monthly_charges = np.array([plan_base_price[p] for p in plans]) + np.random.normal(0, 5, N)
monthly_charges = np.round(np.clip(monthly_charges, 15, 150), 2)
total_charges = np.round(monthly_charges * np.maximum(tenure_months, 1) * np.random.uniform(0.9, 1.0, N), 2)

login_freq_per_week = np.clip(np.random.gamma(3, 1.1, N), 0, 14)
avg_session_minutes = np.clip(np.random.normal(20, 8, N), 2, 90)
days_since_last_login = np.clip(np.random.exponential(scale=10, size=N), 0, 120).astype(int)
support_tickets = np.random.poisson(1.3, N)

engagement_score = (
    (login_freq_per_week / 14) * 0.4
    + (avg_session_minutes / 90) * 0.3
    + (1 - np.clip(days_since_last_login, 0, 60) / 60) * 0.3
)

# --- Build a true underlying churn probability (logit) ---
logit = (
    -2.35
    + 1.4 * (contract_types == "Monthly")
    - 0.9 * (contract_types == "Two-Year")
    - 0.35 * (contract_types == "Annual")
    - 0.9 * engagement_score * 2
    + 0.28 * support_tickets
    + 0.012 * monthly_charges
    - 0.045 * np.minimum(tenure_months, 36) / 6
    + 0.35 * (payment_methods == "Mailed Check")
    - 0.15 * (plans == "Premium")
    + np.random.normal(0, 0.6, N)  # noise
)
churn_prob_true = 1 / (1 + np.exp(-logit))
churned = np.random.binomial(1, churn_prob_true)

df = pd.DataFrame({
    "customer_id": [f"C{10000+i}" for i in range(N)],
    "age": age,
    "gender": gender,
    "location": location,
    "signup_tenure_months": tenure_months,
    "contract_type": contract_types,
    "payment_method": payment_methods,
    "plan": plans,
    "monthly_charges": monthly_charges,
    "total_charges": total_charges,
    "login_freq_per_week": np.round(login_freq_per_week, 1),
    "avg_session_minutes": np.round(avg_session_minutes, 1),
    "days_since_last_login": days_since_last_login,
    "support_tickets": support_tickets,
    "churned": churned,
})

df.to_csv("/home/claude/customer-churn-prediction/data/raw/customers.csv", index=False)
print(df.shape)
print("Churn rate: %.2f%%" % (df["churned"].mean() * 100))
print(df.head())
