-- Master joined view used for modeling and dashboarding
DROP VIEW IF EXISTS customer_master;
CREATE VIEW customer_master AS
SELECT
    c.customer_id,
    c.age,
    c.gender,
    c.location,
    s.plan,
    s.contract_type,
    s.payment_method,
    s.monthly_charges,
    s.total_charges,
    s.tenure_months,
    a.login_freq_per_week,
    a.avg_session_minutes,
    a.days_since_last_login,
    sp.tickets AS support_tickets,
    ch.churned
FROM customers c
JOIN subscriptions s ON c.customer_id = s.customer_id
JOIN activity a       ON c.customer_id = a.customer_id
JOIN support sp       ON c.customer_id = sp.customer_id
JOIN churn ch         ON c.customer_id = ch.customer_id;

-- Overall churn rate
SELECT
    COUNT(*)                                   AS total_customers,
    SUM(churned)                                AS churned_customers,
    ROUND(100.0 * SUM(churned) / COUNT(*), 2)   AS churn_rate_pct
FROM customer_master;

-- Churn rate by contract type
SELECT contract_type,
       COUNT(*)                                 AS customers,
       ROUND(100.0 * SUM(churned) / COUNT(*), 2) AS churn_rate_pct
FROM customer_master
GROUP BY contract_type
ORDER BY churn_rate_pct DESC;

-- Churn rate by tenure bucket
SELECT
    CASE
        WHEN tenure_months <= 6 THEN '0-6 months'
        WHEN tenure_months <= 12 THEN '7-12 months'
        WHEN tenure_months <= 24 THEN '13-24 months'
        ELSE '25+ months'
    END AS tenure_bucket,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(churned) / COUNT(*), 2) AS churn_rate_pct
FROM customer_master
GROUP BY tenure_bucket
ORDER BY MIN(tenure_months);

-- Churn rate by engagement (login frequency proxy)
SELECT
    CASE
        WHEN login_freq_per_week < 2 THEN 'Low engagement'
        WHEN login_freq_per_week < 5 THEN 'Medium engagement'
        ELSE 'High engagement'
    END AS engagement_bucket,
    COUNT(*) AS customers,
    ROUND(100.0 * SUM(churned) / COUNT(*), 2) AS churn_rate_pct
FROM customer_master
GROUP BY engagement_bucket;

-- Revenue at risk from high-probability churners (probability filled in by the ML pipeline)
-- See src/predict.py for the version that joins model scores back into SQL.
