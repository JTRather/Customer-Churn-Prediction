-- Customer Churn Prediction & Retention Analytics Platform
-- Normalized schema (SQLite-compatible, also valid on PostgreSQL/MySQL with minor type tweaks)

DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS subscriptions;
DROP TABLE IF EXISTS activity;
DROP TABLE IF EXISTS support;
DROP TABLE IF EXISTS churn;

CREATE TABLE customers (
    customer_id     TEXT PRIMARY KEY,
    age             INTEGER,
    gender          TEXT,
    location        TEXT
);

CREATE TABLE subscriptions (
    customer_id     TEXT PRIMARY KEY REFERENCES customers(customer_id),
    plan            TEXT,
    contract_type   TEXT,
    payment_method  TEXT,
    monthly_charges REAL,
    total_charges   REAL,
    tenure_months   INTEGER
);

CREATE TABLE activity (
    customer_id          TEXT PRIMARY KEY REFERENCES customers(customer_id),
    login_freq_per_week  REAL,
    avg_session_minutes  REAL,
    days_since_last_login INTEGER
);

CREATE TABLE support (
    customer_id     TEXT PRIMARY KEY REFERENCES customers(customer_id),
    tickets         INTEGER
);

CREATE TABLE churn (
    customer_id     TEXT PRIMARY KEY REFERENCES customers(customer_id),
    churned         INTEGER
);
